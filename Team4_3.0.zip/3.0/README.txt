server main class: com.obfuscation.server.Server
WINDOWS: java -cp server.jar;gson-2.8.5.jar com.obfuscation.server.Server
LINUX:   java -cp server.jar:gson-2.8.5.jar com.obfuscation.server.Server
client main class: com.obfuscation.ttr_phase1b.gameViews.GameActivity
Nexus 5X API 27

KNOWN BUGS:
Occasionally crashes after ticket select screen. Try to make sure that all players have chosen their tickets before pressing "DONE"
The "Show Player Info" button doesn't work.
Not a bug, but every time the map reloads it goes back to the same position, so that's not ideal. Sorry!
