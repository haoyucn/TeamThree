1. FOR WINDOWS:java -cp Server.jar;Shared.jar;jackson-databind-2.9.7.jar;gson-2.6.2.jar;jackson-annotations-2.9.7.jar;jackson-core-2.9.7.jar tickettoride.server.Server 8080

FOR MAC OR LINUX:java -cp Server.jar:Shared.jar:jackson-databind-2.9.7.jar:gson-2.6.2.jar:jackson-annotations-2.9.7.jar:jackson-core-2.9.7.jar tickettoride.server.Server 8080

2. Port number is 8080. Use command line argument "8080"

3. Please test on a Nexus 5X API_26 